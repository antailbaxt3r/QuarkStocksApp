from django.shortcuts import render, redirect
import pyrebase
from .celery import placeOrderBuy, placeOrderSell
from .algo import algo
import time
from django.contrib import auth as dj_auth
from django.contrib import auth
from collections import OrderedDict
from authy.api import AuthyApiClient
from django.conf import settings

config = {
	'apiKey': "AIzaSyDS_XIGRfuaSIwTQbwWF_nSdVlXdM6uvyY",
    'authDomain': "quarkstocksapp.firebaseapp.com",
    'databaseURL': "https://quarkstocksapp.firebaseio.com",
    'projectId': "quarkstocksapp",
    'storageBucket': "quarkstocksapp.appspot.com",
    'messagingSenderId': "779348030725"
}

stockIdMap = {
    'cs01' : { 'name' : 'Neural Networks', 'industry' : 'Computer Science'},
    'cs02' : { 'name' : 'Computer Networks', 'industry' : 'Computer Science'},
    'ece01' : { 'name' : 'Communication systems' , 'industry' : 'Electronics and Communication' },
    'ece02' : { 'name' : 'Microelectronic circuits' , 'industry' : 'Electronics ad Communication' },
    'eee01' : { 'name' : 'Analog Electronics', 'industry' : 'Electrical and Electronics' },
    'eee02' : { 'name' : 'Power Electronics', 'industry' : 'Electrical and Electronics' },
    'bio01' : { 'name' : 'Recombinant DNA Technology', 'industry' : 'Biological Sciences' },
    'bio02' : { 'name' : 'Bioinformatics', 'industry' : 'Biological Sciences' },
    'chem01' : { 'name' : 'Process Design Principles', 'industry' : 'Chemical Engineering' },
    'chem02' : { 'name' : 'Heat Transfer', 'industry' : 'Chemical Engineering' },
    'mech01' : { 'name' : 'Fluid Mechanics', 'industry' : 'Mechanical Engineering' },
    'mech02' : { 'name' : 'Machine Design and Drawing', 'industry' : 'Mechanical Engineering' },
    'math01' : { 'name' : 'Algebra 1', 'industry' : 'Mathematics' },
    'math02' : { 'name' : 'Elementary Real Analysis', 'industry' : 'Mathematics' },
    'eco01' : { 'name' :  'Macro Economics', 'industry' : 'Economics' },
    'eco02' : { 'name' :  'Applied Econometrics', 'industry' : 'Economics' },
    'eni01' : { 'name' : 'Analog and Digital VLSI Design' , 'industry' : 'Electronics and Instrumentation' },
    'eni02' : { 'name' : 'Industrial Instrumentation and Control' , 'industry' : 'Electronics and Instrumentation' }
}

firebase = pyrebase.initialize_app(config)
auth = firebase.auth()
database = firebase.database()
auth = firebase.auth()
database = firebase.database()
authy_api= AuthyApiClient("8x9UksoV9DMM6T1fzMD1tFxayRLrkQnX")

DEFAULT_BAL = 100
user_id = None
def signIn(request):
    if request.method == 'POST' and 'btn1' in request.POST:
        email = request.POST.get('email')
        passw = request.POST.get('pass')
        try:
            user = auth.sign_in_with_email_and_password(email,passw)
        except:
            message="Invalid Credentials"
            return render(request,"signIn.html",{"message":message})

        #print(user['idToken'])
        user = auth.refresh(user['refreshToken'])
        global session_id
        global user_id 

        session_id = user['idToken']
        user_id = auth.get_account_info(user['idToken'])['users'][0]['localId']
        request.session['uid']=str(session_id)
        return redirect(news)
    elif request.method == 'POST' and 'btn2' in request.POST:
        return render(request,'signUp.html')
    return render(request, 'signIn.html')

def profile(request):
    if user_id is None:
        return redirect(signIn)

    idtoken= request.session['uid']
    a = user_id
    e = database.child("users").child(a).child("email").get().val()
    n = database.child("users").child(a).child("name").get().val()
    city = database.child("users").child(a).child("city").get().val()
    p = database.child("users").child(a).child("phone").get().val()
    c = database.child("users").child(a).child("college").get().val()
    r = database.child("users").child(a).child("rank").get().val()
    ac = database.child("users").child(a).child("accBal").get().val()
    return render(request,'profile.html',{"e":e,"n":n,"city":city,"p":p,"c":c,"r":r,"ac":ac})

def ranking(request): #Unfinished algo. TOo heaavy. Need to acquire list from db 
    if user_id is None:
        return redirect(signIn)

    ranklist = []
    new_ranklist=[]
    rank = database.child("users").get()

    for i in rank.each():
        totalEntry = i.val()
        balance = totalEntry['accBal']
        name_user = totalEntry['name']
        rank = totalEntry['rank']

        if rank>0:
            ranklist.append({'name':name_user, 'accBal': balance, 'rank' : rank})

    new_ranklist= sorted(ranklist, key=lambda k: k['rank'])  #OrderedDict(sorted(ranklist.items()))
    return render(request, 'ranking.html', {'new_ranklist': new_ranklist })    
 

def home(request):
	return render(request, 'homepage.html', {"e":'sukdik'})

def news(request):
    if user_id is None:
        return redirect(signIn)

    newslist = []
    news = database.child("news").get()
    for i in news.each():
        newslist.append(i.val())
    return render(request, 'news.html', {'newsList': newslist })

def signOut(request):
    del request.session['uid']
    user_id = None
    return render(request,'signOut.html')

def signUp(request):
    global uid
    if request.method == 'POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        passw=request.POST.get('pass')
        conf_passw=request.POST.get('conf_pass')
        phone=request.POST.get('phone')
        college=request.POST.get('college')
        city=request.POST.get('city')
        print(passw)
        print(conf_passw)

        if passw!=conf_passw:
            message="Password does not match"
            return render(request,'signUp.html',{"message":message})
        elif len(passw)<6:
            message="Password Should be min 6 charachters long"
            return render(request,'signUp.html',{"message":message})
        else:
            emailDB = database.child("users").get()
            for i in emailDB.each():
                temp2 = i.val()
                if email==temp2['email']:
                    message="Email Already Exists"
                    return render(request,'signUp.html',{"message":message})
                             
            if "@goa.bits-pilani.ac.in" in email:
                user=auth.create_user_with_email_and_password(email,passw)
                uid = user['localId']
                data={'name':name,'email':email,'phone': phone, 'college':college,'city':city,'accBal': DEFAULT_BAL, 'rank': 0,'user_verify':"Yes",'userVal':DEFAULT_BAL}
                database.child("users").child(uid).set(data)
                auth.send_email_verification(user['idToken'])
                return render(request,"thankyou.html")
            else:
                phnum = database.child("users").get()
                for i in phnum.each():
                    temp=i.val()
                    if phone==temp['phone']:
                        message="Phone Number Already Exists"
                        return render(request,'signUp.html', {"message":message})

                user=auth.create_user_with_email_and_password(email,passw)
                uid = user['localId']
                data={'name':name,'email':email,'phone': phone, 'college':college,'city':city,'accBal': DEFAULT_BAL, 'rank': 0,'user_verify':"No",'userVal':DEFAULT_BAL}
                database.child("users").child(uid).set(data)
                auth.send_email_verification(user['idToken'])
                return render(request,"verification.html")
        message="could not create account"
        return render(request,'signUp.html', {"message":message})

            
        
        
        	

    return render(request,"signUp.html")
def portfolio(request):
    if user_id is None:
        return redirect(signIn)

    stocksList = [] #list of dictionaries of each individual stock
    stocks = database.child("users").child(user_id).child("stockInfo").get() 
    #Stocks is a dictionary of dictionaies

    for i in stocks.each():
        #temp is a dictionary
        #stocksList is a list of dictionaries
        price = database.child("stocks").child(i.key()).get().val()['currPrice'] 
        temp = i.val()
        temp2 = { 'name' : stockIdMap[i.key()]['name'], 'industry' : stockIdMap[i.key()]['industry'] }

        totalValue = temp['totalValue']
        totalQty = temp['totalQty']
        change = totalQty*price - totalValue
        change = change*100/totalValue 
        
        temp.update({ 'change':  change })
        temp.update(temp2)
        #temp.update({'name' : stockIdMap[i.key()]['name'] })
        stocksList.append(temp)

    return render(request, 'portfolio.html', { 'purchasedStocksList' : stocksList })
 

def trade(request):
    if user_id is None:
        return redirect(signIn)

    if request.method == 'POST':

        errorMsg = ""
        stockQty = int(request.POST.get('stockQty'))
        stockId = str(request.POST.get('stockId'))
        transType = request.POST.get('transType')
        execType = request.POST.get('execType')
        askingPrice = 1

        if stockQty<=0 :
            errorMsg = 'Cannot place order for zero or lesser stocks'
        
        if execType == 'limit':
            if 'limitAskingPrice' not in request.POST:
                askingPrice = 0
            else:
                askingPrice = int(request.POST.get('limitAskingPrice'))
        elif execType == 'stop':
            if 'stopAskingPrice' not in request.POST:
                askingPrice = 0
            else:
                askingPrice = int(request.POST.get('stopAskingPrice'))

        if askingPrice <= 0:
            errorMsg = 'Cannot place an order with that value'

        print(user_id)
        currPrice = int(database.child("stocks").child(stockId).child('currPrice').get().val())
        currBal = int(database.child("users").child(user_id).child('accBal').get().val())
        userStocks = database.child("users").child(user_id).child('stockInfo').child(stockId).child('totalQty').get().val()
        if userStocks is None:
            userStocks = 0

        purValue = stockQty*currPrice
        print(purValue)

        if purValue > 500000:
            return render(request, 'trade.html', {'errorMsg' : 1})
        elif transType == "buy" and purValue > currBal:
            errorMsg = "Insufficient funds to place order"
        elif transType == "sell" and userStocks < stockQty:
            errorMsg = "You do not have enough stocks"

        if execType == "limit" and askingPrice < currPrice :
            errorMsg = 'Cannot demand lower than Stock price when in Limit mode'
        elif execType == "stop" and askingPrice > currPrice:
            errorMsg = 'Cannot demand higher than Stock price when in stop mode'
        elif errorMsg == "":
            errorMsg = algo(currPrice, currBal, purValue, stockQty, transType, execType, askingPrice, stockId, user_id)
            if errorMsg == "":
                return render(request, 'trade.html', { 'success' : 'Order Successfully placed.'})
            else:
                return render(request, 'trade.html', { 'errorMsg' : errorMsg })

        return render(request, 'trade.html', {'errorMsg' : errorMsg })

    return render(request, 'trade.html')    

def orderHistory(request):

    if user_id is None:
        return redirect(signIn)

    orderList = database.child('users').child(user_id).child('orderInfo').order_by_key().get()
    newList = []

    pageSize = 2;
    st = 1
    n=0
    p=0
    reqn = None
    reqp = None

    if request.method == 'POST':
        reqn = request.POST.get('next')
        reqp = request.POST.get('prev')
        if reqn is not None and reqn >= '1':
            st = int(request.POST.get('next')) + pageSize
        elif reqp is not None and reqp >= '1':
            st = int(request.POST.get('prev')) - pageSize
    else:
        st=1

    j=1
    for i in orderList.each():
        if j >= st:
            if j >= st+pageSize:
                break
            newList.append(i.val())
        j = j + 1

    if len(orderList.val()) >= st+pageSize:
        n = st
    else:
        n = 0

    if st > 1:
        p = st 

    print(newList)
    return render(request, 'orderHistory.html', { 'newList' : newList, 'n' : n, 'p' : p })

def chemicalX(request):

    adminList = [
        'PDtt3WiroZOnjneL2YyyIiq4zCp2',
    ]

    if user_id is None:
        return redirect(signIn)
    elif user_id not in adminList:
        return redirect(signIn)

    msg = 'Welcome Powerpuff girls'

    if request.method == 'POST':
        check = request.POST.get('option')
        if check is not None:
            if check == '1':
                msg = 'Sorting'
                allUsers = database.child('users').get()
                finalList = []

                for i in allUsers.each():
                    user = i.val()
                    totVal = 0
                    print(user)

                    if 'stockInfo' in user:
                        print(user['stockInfo'])

                        for key,value in user['stockInfo'].items():
                            totVal += value['totalValue']

                    totVal += user['accBal']
                    listElement = {'rank' : 0, 'name' : user['name'], 'userValue' : totVal }
                    finalList.append(listElement)

                sortedList = sorted(finalList, key=lambda k: k['userValue'], reverse=True)

                j = 1
                for i in sortedList:
                    i.update({'rank' : j})
                    j = j+1

                database.child('ranking').set(sortedList)
                print('Done')


    return render(request, 'chemicalX.html', {'msg' : msg})

def About(request):
    if user_id is None:
        return render(request,'About.html')

    return render(request,'About.html')
def About1(request):
    return render(request,'About1.html')
def FAQ(request):
    return render(request,'FAQ.html')
def email(request):
    return render(request,'email.html')
def stockpages(request):
    return render(request,'stockpages.html')
def verification(request):
    if request.method == 'POST':
        global ph
        ph = request.POST.get('ph')
        request.session['phone_number']=ph
        authy_api.phones.verification_start (
                ph,"91","sms"
        )
        return render(request,'otp.html')
    return render(request,'verification.html' )
def otp(request): 
    global ph
    global uid
    if request.method == 'POST':
        otp= request.POST.get('otp')
        request.session['otp']=otp
        print(otp)
        verification= authy_api.phones.verification_check (

            ph,"91",otp

        )
        if verification.ok():
            request.session['isverified']=True
            message="otp verified"
            database.child("users").child(uid).update({'user_verify' :'Yes'})
            return render(request,'thankyou.html')
        else:       
            return render(request,'otp.html')      
    return render(request,'otp.html')           

