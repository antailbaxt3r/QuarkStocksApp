from .celery import placeOrderBuy, placeOrderSell

def algo(currPrice, currBal, purValue, stockQty, transType, execType, askPrice, stockId, user_id):

    askRatio = askPrice/currPrice

    if stockQty >= 1500:
        delayTime = 60
    elif stockQty >= 1200:
        delayTime = 45
    elif stockQty >= 1000:
        delayTime = 30
    elif stockQty >= 750:
        delayTime = 10
    elif stockQty >= 250:
        delayTime = 4
    else: 
        delayTime = 0
    
    if execType == "stop" or execType == "limit":
        if currPrice < 100 and askRatio >= 0.95 and askRatio <= 1.05: #
            if askRatio >= 0.995 and askRatio <= 1.005: #0.005 times
                delayTime += 4
            elif askRatio >= 0.988 and askRatio <= 1.012: #0.012 times
                delayTime += 10
            elif askRatio >= 0.98 and askRatio <= 1.02: #0.02 times
                delayTime += 20
            elif askRatio >= 0.96 and askRatio <= 1.04: # 0.04 times
                delayTime += 40
            else:
                delayTime += 75
        
        elif currPrice < 300 and askRatio >= 0.98 and askRatio <= 1.02: #
            if askRatio >= 0.997 and askRatio <= 1.003:
                delayTime += 4
            elif askRatio >= 0.9945 and askRatio <= 1.0055:
                delayTime += 10
            elif askRatio >= 0.992 and askRatio <= 1.008:
                delayTime += 20
            elif askRatio >= 0.985 and askRatio <= 1.015:
                delayTime += 45
            else:
                delayTime += 90
        
        elif currPrice < 400 and askRatio >= 0.988 and askRatio <= 1.012:
            if askRatio >= 0.996 and askRatio <= 1.004:
                delayTime += 4
            elif askRatio >= 0.994 and askRatio <= 1.006:
                delayTime += 12
            elif askRatio >= 0.992 and askRatio <= 1.008:
                delayTime += 35
            elif askRatio >= 0.99 and askRatio <= 1.01:
                delayTime += 60
            else:
                delayTime += 80

        elif currPrice < 800 and askRatio >= 0.988 and askRatio <= 1.012:
            if askRatio >= 0.998 and askRatio <= 1.002:
                delayTime += 4
            elif askRatio >= 0.9975 and askRatio <= 1.0025:
                delayTime += 12
            elif askRatio >= 0.996 and askRatio <= 1.004:
                delayTime += 18
            elif askRatio >= 0.993 and askRatio <= 1.007:
                delayTime += 45
            elif askRatio >= 0.991 and askRatio <= 1.009:
                delayTime += 75
            else:
                delayTime += 120
        
        elif currPrice < 1200 and askRatio >= 0.992 and askRatio <= 1.008:
            if askRatio >= 0.998 and askRatio <= 1.002:
                delayTime += 4
            elif askRatio >= 0.9975 and askRatio <= 1.0025:
                delayTime += 12
            elif askRatio >= 0.996 and askRatio <= 1.004:
                delayTime += 18
            elif askRatio >= 0.9945 and askRatio <= 1.0055:
                delayTime += 45
            elif askRatio >= 0.993 and askRatio <= 1.007:
                delayTime += 75
            else:
                delayTime += 120
        else:
            return "The order will not be possible at this time. No available buyers/sellers at the price"
    
    if delayTime > 45:
        print("Gonna take long af")
        #display warning    


    print("Delaying for " + str(delayTime))

    if execType == "market":
        data = {'currPrice' : currPrice}
    elif execType == "stop" or execType == "limit":
        data = {'currPrice' : askPrice}
    else:
        return "Invalid trade execution type. Don't fuck with the website."
    

    if transType == 'buy':
        print('buying')
        currBal = currBal - purValue
        data2 = {'accBal' : currBal}
        placeOrderBuy.delay(data, user_id, data2, stockId, stockQty, delayTime)
    elif transType == 'sell':
        print('selling')
        currBal = currBal + purValue
        data2 = {'accBal' : currBal}
        placeOrderSell.delay(data, user_id, data2, stockId, stockQty, delayTime)
    else:
        return "Invalid transaction type. Don't fuck with the website."
    
    return ""