from __future__ import absolute_import, unicode_literals
import os
from celery import Celery
import pyrebase 
import time

config = {
    'apiKey': "AIzaSyDS_XIGRfuaSIwTQbwWF_nSdVlXdM6uvyY",
    'authDomain': "quarkstocksapp.firebaseapp.com",
    'databaseURL': "https://quarkstocksapp.firebaseio.com",
    'projectId': "quarkstocksapp",
    'storageBucket': "quarkstocksapp.appspot.com",
    'messagingSenderId': "779348030725"
}

firebase = pyrebase.initialize_app(config)
database = firebase.database()
# set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quark.settings')

app = Celery('quark')

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
app.config_from_object('django.conf:settings', namespace='CELERY')

# Load task modules from all registered Django app configs.
app.autodiscover_tasks()

stockIdMap = {
    'cs01' : { 'name' : 'Neural Networks', 'industry' : 'Computer Science'},
    'cs02' : { 'name' : 'Computer Networks', 'industry' : 'Computer Science'},
    'ece01' : { 'name' : 'Communication systems' , 'industry' : 'Electronics and Communication' },
    'ece02' : { 'name' : 'Microelectronic circuits' , 'industry' : 'Electronics ad Communication' },
    'eee01' : { 'name' : 'Analog Electronics', 'industry' : 'Electrical and Electronics' },
    'eee02' : { 'name' : 'Power Electronics', 'industry' : 'Electrical and Electronics' },
    'bio01' : { 'name' : 'Recombinant DNA Technology', 'industry' : 'Biological Sciences' },
    'bio02' : { 'name' : 'Bioinformatics', 'industry' : 'Biological Sciences' },
    'chem01' : { 'name' : 'Process Design Principles', 'industry' : 'Chemical Engineering' },
    'chem02' : { 'name' : 'Heat Transfer', 'industry' : 'Chemical Engineering' },
    'mech01' : { 'name' : 'Fluid Mechanics', 'industry' : 'Mechanical Engineering' },
    'mech02' : { 'name' : 'Machine Design and Drawing', 'industry' : 'Mechanical Engineering' },
    'math01' : { 'name' : 'Algebra 1', 'industry' : 'Mathematics' },
    'math02' : { 'name' : 'Elementary Real Analysis', 'industry' : 'Mathematics' },
    'eco01' : { 'name' :  'Macro Economics', 'industry' : 'Economics' },
    'eco02' : { 'name' :  'Applied Econometrics', 'industry' : 'Economics' },
    'eni01' : { 'name' : 'Analog and Digital VLSI Design' , 'industry' : 'Electronics and Instrumentation' },
    'eni02' : { 'name' : 'Industrial Instrumentation and Control' , 'industry' : 'Electronics and Instrumentation' }
}

@app.task
def placeOrderBuy(data, user_id, data2, stockId, stockQty, t):
    time.sleep(t)
    timeStr = str(time.strftime('%d %H_%M_%S_'))+ stockId
    currStock = database.child("users").child(user_id).child('stockInfo').child(stockId).child('totalQty').get().val()
    currStockValue = database.child("users").child(user_id).child('stockInfo').child(stockId).child('totalValue').get().val()
    
    if currStock is None:
        currStock = stockQty
        currStockValue = stockQty*data['currPrice']
    else:
        currStock += stockQty
        currStockValue += stockQty*data['currPrice']

    dataStock = {'totalQty' : currStock, 'totalValue' : currStockValue }
    dataOrder = { 'name' : stockIdMap[stockId]['name'], 'orderQty' : stockQty, 'orderPrice' : data['currPrice'], 'type' : 'buy'}

    database.child("users").child(user_id).update(data2)    #user balance update
    database.child("users").child(user_id).child('stockInfo').child(stockId).set(dataStock)  
    database.child("users").child(user_id).child('orderInfo').child(timeStr).set(dataOrder)  
    database.child("stocks").child(stockId).update(data)    #commodity price update

@app.task
def placeOrderSell(data, user_id, data2, stockId, stockQty, t):
    time.sleep(t)
    timeStr = str(time.strftime('%d %H_%M_%S_'))+ stockId
    currStock = database.child("users").child(user_id).child('stockInfo').child(stockId).child('totalQty').get().val()
    currStockValue = database.child("users").child(user_id).child('stockInfo').child(stockId).child('totalValue').get().val()
    
    currStock -= stockQty
    currStockValue -= stockQty*data['currPrice']
    
    dataStock = {'totalQty' : currStock, 'totalValue' : currStockValue}
    dataOrder = { 'name' :  stockIdMap[stockId], 'orderQty' : stockQty, 'orderPrice' : data['currPrice'], 'type' : 'sell'}

    database.child("users").child(user_id).update(data2)
    database.child("users").child(user_id).child('stockInfo').child(stockId).set(dataStock)
    database.child("users").child(user_id).child('orderInfo').child(timeStr).set(dataOrder)
    database.child("stocks").child(stockId).update(data)
    